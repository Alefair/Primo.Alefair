﻿using LTools.Common.Helpers;
using LTools.Common.Model;
using LTools.Common.UIElements;
using LTools.Common.WFItems;
using LTools.SDK;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Primo.My.Activity.Activities
{
    public class MyFirstActivity : PrimoComponentSimple<Design.MyFirstActivity_Form>
    {
        #region [GROUP NAME]

        public override string GroupName
        {
            get => "My{\\}MyFirstActivity";
            protected set { }
        }

        #endregion


        #region [GLOBAL VARIABLE]

        private Design.MyFirstActivity_Form cbase;
        private string in_argument;
        private string out_argument;


        #endregion


        #region [PROPERTIES]



        ///In_Argument
        /// 
        [LTools.Common.Model.Serialization.StoringProperty]
        [LTools.Common.Model.Studio.ValidateReturnScript(DataType = typeof(string))]
        [Category("In_Argument"), DisplayName("In_Argument")]
        [DefaultValue(0)]
        public string In_Argument
        {
            get { return this.in_argument; }
            set { this.in_argument = value; this.InvokePropertyChanged(this, nameof(In_Argument)); }
        }


        /// Out_Argument
        /// 
        [LTools.Common.Model.Serialization.StoringProperty]
        [LTools.Common.Model.Studio.ValidateReturnScript(DataType = typeof(string))]
        [Category("Out_Argument"), DisplayName("Out_Argument")]
        [DefaultValue(0)]
        public string Out_Argument
        {
            get { return this.out_argument; }
            set { this.out_argument = value; this.InvokePropertyChanged(this, nameof(Out_Argument)); }
        }

        #endregion


        #region [PROPERTIES][TYPES]

        public MyFirstActivity(IWFContainer container) : base(container)
        {
            sdkComponentIcon = "pack://application:,,/Primo.My.Activity;component/Images/eye_ico.png";

            sdkComponentName = "My First Activity";
            sdkComponentHelp = "In the activity, you can specify a path and it will be filled into a string variable";


            ///[PROPERTIES]
            ///
            sdkComponentHelp += "\r\n" + "\r\n" + "[Properties]";


            sdkComponentHelp += "\r\n"
                             + nameof(In_Argument) + "*: "
                             + "The Path";


            ///[Output]
            sdkComponentHelp += "\r\n" + "\r\n" + "[Output]";

            sdkComponentHelp += "\r\n"
                             + nameof(Out_Argument) + "*: "
                             + "Variable for Set";



            sdkProperties = new List<LTools.Common.Helpers.WFHelper.PropertiesItem>()
            {
                new LTools.Common.Helpers.WFHelper.PropertiesItem()
                {
                    PropName = nameof(In_Argument),
                    PropertyType = LTools.Common.Helpers.WFHelper.PropertiesItem.PropertyTypes.SCRIPT,
                    EditorType = ScriptEditorTypes.NONE,
                    DataType = typeof(string),
                    ToolTip = nameof(In_Argument),
                    IsReadOnly = false
                },


                new LTools.Common.Helpers.WFHelper.PropertiesItem()
                {
                    PropName = nameof(Out_Argument),
                    PropertyType = LTools.Common.Helpers.WFHelper.PropertiesItem.PropertyTypes.VARIABLE,
                    EditorType = ScriptEditorTypes.NONE,
                    DataType = typeof(string),
                    ToolTip = nameof(Out_Argument),
                    IsReadOnly = false
                }
            };

            InitClass(container);



            ///Create Instance of MyFirstActivity_Form
            try
            {
                Design.MyFirstActivity_Form inputform = new Design.MyFirstActivity_Form();


                this.cbase = inputform;
                this.cbase.DataContext = (object)this;
                WFElement wfElement = new WFElement((IWFElement)this, container);
                this.element = wfElement;

                ///Create Event if Buttons is clicked
                ///
                this.cbase.Form_btn.Click += new RoutedEventHandler(this.MyFirstActivity_Form_btn_Click);

                this.element.Container = (FrameworkElement)this.cbase;

            }
            catch
            {
            }

            ///Value by Default of "In_argument" argument
            this.In_Argument = "\"Choose path...\"";
        }


        #endregion


        #region [EXECUTION]


        public override ExecutionResult SimpleAction(ScriptingData sd)
        {
            try
            {
                #region [VARIABLES][INIT]
                string property_In_Argument = GetPropertyValue<string>(this.In_Argument, nameof(In_Argument), sd);

                #endregion

                #region [PROCESS]

                

                #endregion

                #region [OUTPUT]

                WFHelper.AssignToVariable(
                    this.out_argument,
                    property_In_Argument,
                    property_In_Argument.GetType(),
                    sd.Variables
                );

                #endregion

                ExecutionResult executionResult = new ExecutionResult();
                executionResult.SuccessMessage = "Done";
                executionResult.IsSuccess = true;

                return executionResult;
            }
            catch (Exception ex)
            {
                ExecutionResult executionResult = new ExecutionResult();
                executionResult.ErrorMessage = ex?.Message;
                executionResult.IsSuccess = false;

                return executionResult;
            }
        }


        #endregion


        #region [VALIDATE]
        public override ValidationResult Validate()
        {
            ValidationResult ret = new ValidationResult();
            if (System.String.IsNullOrEmpty(this.In_Argument)) ret.Items.Add(new ValidationResult.ValidationItem() { PropertyName = nameof(Out_Argument), Error = "It should not be empty!" });
            return ret;
        }

        #endregion


        #region [ADVANCED]
        private void MyFirstActivity_Form_btn_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
            openFileDlg.Filter = "Excel files (*.xls; *.xlsx)|*.xls;*.xlsx";
            if (openFileDlg.ShowDialog() == true) this.In_Argument = "@\"" + openFileDlg.FileName + "\"";
        }
        #endregion
    }
}
